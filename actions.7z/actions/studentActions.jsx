import { Dispatch } from 'redux'
import axios from 'axios'

export const addStudentDetails = (dispatch, studentData ) => {
    const _userURL = 'http://localhost:8000/api/addStudentDetails'
  
    axios.post(_userURL, {
        
        studentFirstName: studentData.firstName,
        studentLastName: studentData.lastName, 
        studentAadharNumber: studentData.aadharNumber,
        studentBirthPlace: studentData.birthPlace,
        studentNationality: studentData.nationality,
        studentGender: studentData.gender,
        studentReligion: studentData.religion,
        studentCaste: studentData.caste,
        studentCategory: studentData.category,
        studentDOB: studentData.DOB,
        studentIsBlind: studentData.isBlind,
        studentIsMinority: studentData.isMinority,
        studentIncomeGroup: studentData.isIncomeGroup,   
        studentIsPH: studentData.isPH,
        studentIsBPL: studentData.isBPL,
        studentPermanentaddress: studentData.permanentAddress,
        studentCorrespondenceAddress: studentData.correspondenceAddress,
        studentFatherName: studentData.fatherName,
        studentFatherOccupation: studentData.fatherOccupation,
        studentParentEmail: studentData.parentEmailId,
        studentMobileNo: studentData.parentMobileNumber,
        studentFatherIncome: studentData.parentIncome
        
        }).then(({ data }) => {
     
       console.log('add staff payment', data)

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)
             
    })

}



export const addStudentPreAdmissionDetails = (dispatch, studentData ) => {
    const _userURL = 'http://localhost:8000/api/addStudentPreAdmissionDetails'
  
    axios.post(_userURL, {
        
        studentId: studentData.studentId,
        academicYearName: studentData.academicyear,
        studentPrevWillingClass: studentData.class,
        studentPrevClass: studentData.previousClass,
        studentTotalFee: studentData.totalFee,
        studentInitialFeePaid: studentData.initialFeePaid,
        studentPrevAppNo : studentData.prevAdmissionAppNo
        
        }).then(({ data }) => {
     
       console.log('add staff payment', data)

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)
             
    })

}


export const addStudentPreInstitutionDetails = (dispatch, studentData ) => {
    const _userURL = 'http://localhost:8000/api/addStudentPreInstitutionDetails'
  
    axios.post(_userURL, {
        
        studentId: studentData.studentId,
        prevInstitutionName: studentData.prevInstitutionName,
        prevRegisteredNumber: studentData.prevRegistrationNumber,
        prevInstitutionAddress: studentData.previnstitutionAddress,
        prevYearOfPassing: studentData.prevYearofPassing,
        prevExamPassed: studentData.isPassed
        
        }).then(({ data }) => {
     
       console.log('add staff payment', data)

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)
             
    })

}


export const addStudentAdmissionDetails = (dispatch, studentData ) => {
    const _userURL = 'http://localhost:8000/api/addStudentAdmissionDetails'
  
    axios.post(_userURL, {
        
        studentId: studentData.studentId,
        studentAdmissionRegistrationNumber: studentData.admissionRegistrationNumber,
        studentAdmissionRollNumber: studentData.admissionRollNumber,
        studentAdmissionFeeConcision: studentData.admissionFeeConcision,
        studentAdmissionRemainingAmount: studentData.admissionRemainingAmount
        
        }).then(({ data }) => {
     
       console.log('add staff payment', data)

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)
             
    })

}



export const modifyStudentDetails = (dispatch, studentData ) => {
    const _userURL = 'http://localhost:8000/api/modifyStudentDetails'
  
    axios.put(_userURL, {
        
        studentId: studentData.studentId,
        studentFirstName: studentData.firstName,
        studentLastName: studentData.lastName, 
        studentAadharNumber: studentData.aadharNumber,
        studentBirthPlace: studentData.birthPlace,
        studentNationality: studentData.nationality,
        studentGender: studentData.gender,
        studentReligion: studentData.religion,
        studentCaste: studentData.caste,
        studentCategory: studentData.category,
        studentDOB: studentData.DOB,
        studentIsBlind: studentData.isBlind,
        studentIsMinority: studentData.isMinority,
        studentIncomeGroup: studentData.isIncomeGroup,   
        studentIsPH: studentData.isPH,
        studentIsBPL: studentData.isBPL,
        studentPermanentaddress: studentData.permanentAddress,
        studentCorrespondenceAddress: studentData.correspondenceAddress,
        studentFatherName: studentData.fatherName,
        studentFatherOccupation: studentData.fatherOccupation,
        studentParentEmail: studentData.parentEmailId,
        studentMobileNo: studentData.parentMobileNumber,
        studentFatherIncome: studentData.parentIncome
        
        }).then(({ data }) => {
     
       console.log('add staff payment', data)

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)
             
    })

}



export const modifyStudentPreAdmissionDetails = (dispatch, studentData ) => {
    const _userURL = 'http://localhost:8000/api/modifyStudentPreAdmissionDetails'
  
    axios.put(_userURL, {
        
        studentId: studentData.studentId,
        academicYearName: studentData.academicyear,
        studentPrevWillingClass: studentData.class,
        studentPrevClass: studentData.previousClass,
        studentTotalFee: studentData.totalFee,
        studentInitialFeePaid: studentData.initialFeePaid,
        studentPrevAppNo : studentData.prevAdmissionAppNo
        
        }).then(({ data }) => {
     
       console.log('add staff payment', data)

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)
             
    })

}


export const modifyStudentPreInstitutionDetails = (dispatch, studentData ) => {
    const _userURL = 'http://localhost:8000/api/modifyStudentPreInstitutionDetails'
  
    axios.put(_userURL, {
        
        studentId: studentData.studentId,
        prevInstitutionName: studentData.prevInstitutionName,
        prevRegisteredNumber: studentData.prevRegistrationNumber,
        prevInstitutionAddress: studentData.previnstitutionAddress,
        prevYearOfPassing: studentData.prevYearofPassing,
        prevExamPassed: studentData.isPassed
        
        }).then(({ data }) => {
     
       console.log('add staff payment', data)

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)
             
    })

}


export const modifyStudentAdmissionDetails = (dispatch, studentData ) => {
    const _userURL = 'http://localhost:8000/api/modifyStudentAdmissionDetails'
  
    axios.put(_userURL, {
        
        studentId: studentData.studentId,
        studentAdmissionRegistrationNumber: studentData.admissionRegistrationNumber,
        studentAdmissionRollNumber: studentData.admissionRollNumber,
        studentAdmissionFeeConcision: studentData.admissionFeeConcision,
        studentAdmissionRemainingAmount: studentData.admissionRemainingAmount
        
        }).then(({ data }) => {
     
       console.log('add staff payment', data)

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)
             
    })

}


export const addStaffPayment = (dispatch, staffPaymentData ) => {
    const _userURL = 'http://localhost:8000/api/staffpayment'


   
    axios.put(_userURL, {
        
       
     
        
        }).then(({ data }) => {

      
       console.log('add staff payment', data)
            

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)

              
    })

}


