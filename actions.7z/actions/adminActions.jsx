import { Dispatch } from 'redux'
import axios from 'axios'



export const addAcademicYear = (dispatch, academicYearData) => {
    const _userURL = 'http://localhost:8000/api/addAcademicyear'

    axios.post(_userURL, {
        
        academicYearName: academicYearData.academicYear,
        academicReceiptNumber: academicYearData.academicReceiptNumber,
        academicFrom: academicYearData.academicStartDate,
        academicTo: academicYearData.academicEndDate,
        
       
        
        }).then(({ data }) => {

            console.log('addAcademicYearAction data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create academic year : ', error)

                   
    })

}


export const modifyAcademicYear = (dispatch, academicYearData ) => {
    const _userURL = 'http://localhost:8000/api/modifyAcademicYear'

   
    axios.put(_userURL, {
        
        academicId: academicYearData.academicId,
        academicYearName: academicYearData.academicYear,
        academicReceiptNumber: academicYearData.academicReceiptNumber,
        academicFrom: academicYearData.academicStartDate,
        academicTo: academicYearData.academicEndDate,

        }).then(({ data }) => {

      
       console.log('edit academic year data', data)
            

    }).catch((error) => {
        console.warn('Failed to update academic year : ', error)
             
    })

}



export const addMedium = (dispatch, mediumData) => {
    const _userURL = 'http://localhost:8000/api/addMedium'

    axios.post(_userURL, {
        
        mediumName: mediumData.mediumName,
           
        }).then(({ data }) => {

            console.log('mediumData data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create medium  : ', error)

                   
    })

}


export const modifyMedium = (dispatch, mediumData ) => {
    const _userURL = 'http://localhost:8000/api/modifyMedium'

   
    axios.put(_userURL, {
        
        mediumId: mediumData.mediumId,
        mediumName: mediumData.mediumName,
        
        }).then(({ data }) => {

      
       console.log('edit medium data', data)
            

    }).catch((error) => {
        console.warn('Failed to update medium : ', error)
             
    })

}


export const addReligion = (dispatch, religionData) => {
    const _userURL = 'http://localhost:8000/api/addReligion'

    axios.post(_userURL, {
        
        religionName: religionData.religionName,
           
        }).then(({ data }) => {

            console.log('religion data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create religion  : ', error)

                   
    })

}


export const modifyReligion = (dispatch, religionData ) => {
    const _userURL = 'http://localhost:8000/api/modifyReligion'

   
    axios.put(_userURL, {
        
        idReligion: religionData.religionId,
        religionName: religionData.religionName,
        
        }).then(({ data }) => {

      
       console.log('edit religion data', data)
            

    }).catch((error) => {
        console.warn('Failed to update religion : ', error)
             
    })

}

export const addCaste = (dispatch, casteData) => {
    const _userURL = 'http://localhost:8000/api/addCaste'

    axios.post(_userURL, {
        
        casteName: casteData.casteName,
           
        }).then(({ data }) => {

            console.log('caste data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create caste  : ', error)

                   
    })

}


export const modifyCaste = (dispatch, casteData ) => {
    const _userURL = 'http://localhost:8000/api/modifyCaste'

   
    axios.put(_userURL, {
        
        idCaste: casteData.casteId,
        casteName: casteData.casteName,
        
        }).then(({ data }) => {

      
       console.log('edit caste data', data)
            

    }).catch((error) => {
        console.warn('Failed to update caste : ', error)
             
    })

}


export const addCategory = (dispatch, categoryData) => {
    const _userURL = 'http://localhost:8000/api/addCategory'

    axios.post(_userURL, {
        
        categoryName: categoryData.categoryName,
           
        }).then(({ data }) => {

            console.log('category data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create category  : ', error)

                   
    })

}


export const modifyCategory = (dispatch, categoryData ) => {
    const _userURL = 'http://localhost:8000/api/modifyCategory'

   
    axios.put(_userURL, {
        
        idCategory: categoryData.categoryId,
        categoryName: categoryData.categoryName,
        
        
        }).then(({ data }) => {

      
       console.log('edit category data', data)
            

    }).catch((error) => {
        console.warn('Failed to update category : ', error)
             
    })

}


export const addClass = (dispatch, classData) => {
    const _userURL = 'http://localhost:8000/api/addClass'

    axios.post(_userURL, {
        
        className: classData.className,
        classDescription: classData.classDescription,
        classPrimary: classData.isPrimary

        }).then(({ data }) => {

            console.log('class data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create class  : ', error)

                   
    })

}


export const modifyClass = (dispatch, classData) => {
    const _userURL = 'http://localhost:8000/api/modifyClass'

    axios.put(_userURL, {
        idClass: classData.classId,
        className: classData.className,
        classDescription: classData.classDescription,
        classPrimary: classData.isPrimary

        }).then(({ data }) => {

            console.log('class data', data)
         

    }).catch((error) => {
        console.warn('Failed to edit class  : ', error)

                   
    })

}


export const addSection = (dispatch, sectionData) => {
    const _userURL = 'http://localhost:8000/api/addSection'

    axios.post(_userURL, {
        
        sectionName: sectionData.sectionName,
      

        }).then(({ data }) => {

            console.log('section data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create section  : ', error)

                   
    })

}


export const  modifySection = (dispatch, sectionData) => {
    const _userURL = 'http://localhost:8000/api/modifySection'

    axios.put(_userURL, {
        idSection: sectionData.sectionId, 
        sectionName: sectionData.sectionName,
      

        }).then(({ data }) => {

            console.log('section data', data)
         

    }).catch((error) => {
        console.warn('Failed to edit section  : ', error)

                   
    })

}

export const addSubjectype = (dispatch, subjectTypeData) => {
    const _userURL = 'http://localhost:8000/api/addSubjectType'

    axios.post(_userURL, {
        
        subjectTypeName: subjectTypeData.subjectTypeName,
      

        }).then(({ data }) => {

            console.log('subject Type data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create subject Type  : ', error)

                   
    })

}


export const modifySubjectype = (dispatch, subjectTypeData) => {
    const _userURL = 'http://localhost:8000/api/modifySubjectype'

    axios.put(_userURL, {
        
        idSubjectType: subjectTypeData.subjectTypeId,
        subjectTypeName: subjectTypeData.subjectTypeName,
      

        }).then(({ data }) => {

            console.log('subject Type data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create subject Type  : ', error)

                   
    })

}


export const addSubject = (dispatch, subjectData) => {
    const _userURL = 'http://localhost:8000/api/addSubject'

    axios.post(_userURL, {
        
        subjectMediumType: subjectData.subjectMediumType,
        subjectType: subjectData.subjectType,
        subjectCode: subjectData.subjectCode,
        subjectTypeName: subjectData.subjectName
      

        }).then(({ data }) => {

            console.log('subject data', data)
         

    }).catch((error) => {
        console.warn('Failed to add subject  : ', error)

                   
    })

}

export const modifySubject = (dispatch, subjectData) => {
    const _userURL = 'http://localhost:8000/api/modifySubject'

    axios.put(_userURL, {
        
        idSubject: subjectData.subjectId,
        subjectMediumType: subjectData.subjectMediumType,
        subjectType: subjectData.subjectType,
        subjectCode: subjectData.subjectCode,
        subjectTypeName: subjectData.subjectName
      

        }).then(({ data }) => {

            console.log('subject data', data)
         

    }).catch((error) => {
        console.warn('Failed to update subject  : ', error)

                   
    })

}