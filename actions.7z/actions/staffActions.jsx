import { Dispatch } from 'redux'
import axios from 'axios'



export const addStaffAction = (dispatch, staffData) => {
    const _userURL = 'http://localhost:8000/api/addstaff'

    axios.post(_userURL, {
        
        staffFirstName: staffData.firstName,
        staffLastName: staffData.lastName, 
        staffAadharNumber: staffData.aadharNumber,
        staffGender: staffData.gender,
        staffDOB: staffData.DOB,
        staffNationality: staffData.nationality,
        staffPermanentaddress: staffData.permanentAddress,
        staffCorrespondenceAddress: staffData.correspondenceAddress
       
        
        }).then(({ data }) => {

            console.log('addStaffAction data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create staff : ', error)

                   
    })

}


export const editStaff = (dispatch, staffData ) => {
    const _userURL = 'http://localhost:8000/api/editstaff'

    console.log('edit staff ', data)

   
    axios.put(_userURL, {
        
        staffId: staffData.staffId,
        staffFirstName: staffData.firstName,
        staffLastName: staffData.lastName, 
        staffAadharNumber: staffData.aadharNumber,
        staffGender: staffData.gender,
        staffDOB: staffData.DOB,
        staffNationality: staffData.nationality,
        staffPermanentaddress: staffData.permanentAddress,
        staffCorrespondenceAddress: staffData.correspondenceAddress
        
        }).then(({ data }) => {

      
       console.log('edit staff data', data)
            

    }).catch((error) => {
        console.warn('Failed to update staff : ', error)

              
    })

}


export const addStaffPayment = (dispatch, staffPaymentData ) => {
    const _userURL = 'http://localhost:8000/api/staffpayment'


   
    axios.put(_userURL, {
        
        employee_id: staffPaymentData.staffName,
        name: staffPaymentData.ta, 
        name: staffPaymentData.da,
        mo: staffPaymentData.hra,
        working: staffPaymentData.basic,
        photo: staffPaymentData.specialAllowance,
        total: staffPaymentData.total
     
        
        }).then(({ data }) => {

      
       console.log('add staff payment', data)
            

    }).catch((error) => {
        console.warn('Failed to update staff payment : ', error)

              
    })

}


