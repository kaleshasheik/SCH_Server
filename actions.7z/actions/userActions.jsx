import { Dispatch } from 'redux'
import axios from 'axios'



export const loadUsers = (dispatch) => {
    const _userURL = 'http://localhost:8000/api/fetchUsers'

    axios.get(_userURL).then(({ data }) => {

            console.log('loadUsers data', data)
        

    }).catch((error) => {
        console.warn('Failed to loadUsers : ', error)

      
              
    })

}


export const addUser = (dispatch, userData) => {
    const _userURL = 'http://localhost:8000/api/adduser'

    axios.post(_userURL, {
        
        userType: userData.userType,
        userName: userData.userName, 
        userEmailId: userData.emailId,
        userMobileNumber: userData.mobileNo,
        userStatus: userData.isWorking,
        userImage: userData.image
       
        
        }).then(({ data }) => {

            console.log('addUserAction data', data)
         

    }).catch((error) => {
        console.warn('Failed to Create user : ', error)

                   
    })

}


export const modifyUser = (dispatch, userData ) => {
    const _userURL = 'http://localhost:8000/api/modifyUser'

    console.log('edit user ', data)

   
    axios.put(_userURL, {
        
        userId: userData.userId,
        userType: userData.userType,
        userName: userData.userName, 
        userEmailId: userData.emailId,
        userMobileNumber: userData.mobileNo,
        userStatus: userData.isWorking,
        userImage: userData.image
        
        }).then(({ data }) => {

      
       console.log('edit user data', data)
            

    }).catch((error) => {
        console.warn('Failed to update user : ', error)

              
    })

}



