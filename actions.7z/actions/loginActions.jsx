import { Dispatch } from 'redux'
import axios from 'axios'

export const login = (dispatch, user, password) => {
    const _loginURL = 'http://localhost:8000/api/login'
    return axios.post(_loginURL, {

        email: user,
        password: password

    }).then(({ data }) => {

        console.log('login data', data)
       
     

    }).catch((error) => {
        console.warn('Login error', error)
       
    })

}


export const resetPassword = (dispatch, user, password) => {
    const _resetPasswordURL = 'http://localhost:8000/api/resetPassword'
    return axios.put(_resetPasswordURL, {

        email: user,
        password: password,
         
    }).then(({ data }) => {

        console.log('login data', data)
        

    }).catch((error) => {
        console.warn('resetPassword error', error)

    })

}


export const forgetPassword = (dispatch, emailId) => {
    const _forgetPasswordURL = 'http://localhost:8000/api/forgetPassword'
    return axios.put(_forgetPasswordURL, {
        email: emailId,
    }).then(({ data }) => {

  console.log(data)
       

    }).catch((error) => {
        console.warn('forgetpwd error', error)

    })

}



export const clearMessages = (dispatch) => {


}